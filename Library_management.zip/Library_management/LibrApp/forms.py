from django import forms
from .models import Book, User

class ContactForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['name','contact', 'email', 'address','enrollment']
        
    def __init__(self, *args, **kwargs):
        super(ContactForm, self).__init__(*args, **kwargs)
        self.fields['enrollment'].queryset = Book.objects.order_by('book_name')


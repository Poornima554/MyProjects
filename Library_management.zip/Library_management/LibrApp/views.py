from django.http import HttpResponse
from django.shortcuts import render
from django.contrib import messages

# Create your views here.
from django.shortcuts import render, redirect

from LibrApp.models import Book, User
from .forms import ContactForm
from django.http import JsonResponse
from django.shortcuts import get_object_or_404

def home(request):
    return render(request,"base.html")

def book_details(request):
    books=Book.objects.all().order_by('book_name')
    return render(request,'book.html',{"books":books})

def borrow_record(request):
    users = User.objects.all().order_by('name')
    books = Book.objects.all()
    return render(request, 'borrow.html', {"users": users, "books": books})

def record_c(request):
    if request.method == "POST":
        user_id = request.POST['uname1']
        user = User.objects.get(id=user_id)
        books = user.enrollment.all()  # Fetch all books related to the user
        return render(request, 'borr_details.html', {"books": books})
    else:
        users = User.objects.all()
        return render(request, 'borrow.html', {"users": users})
   


def delete_book(request, book_id):
    if request.method == 'DELETE':
        book = get_object_or_404(Book, pk=book_id)
        book.delete()
        messages.success(request, 'Book deleted successfully')
        return JsonResponse({'message': 'Book deleted Successfully'}, status=200)
    messages.error(request, 'Invalid request method')
    return JsonResponse({'error': 'Invalid request method'}, status=400)




def form_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()  # Save the form data to the database
            return render(request,"ur_temp.html")
    else:
        form = ContactForm()

    return render(request, 'my_template.html', {'form': form})
